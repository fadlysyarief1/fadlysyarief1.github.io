import type { Metadata, Viewport } from "next";
import { Poppins, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const poppins = Poppins({ subsets: ["latin"], weight: ["400", "500", "600", "700", "800"], variable: "--font-poppins", display: "swap" });
const mono = JetBrains_Mono({ subsets: ["latin"], weight: ["400", "600"], variable: "--font-mono", display: "swap" });

export const metadata: Metadata = {
  title: "Zulfadhli Syarif — Fullstack Software Developer",
  description:
    "CV Zulfadhli Syarif, Fullstack Software Developer (Laravel, NestJS, Next.js, Go, Flutter). Medan – Jakarta – Palembang – All Indonesia.",
  openGraph: {
    title: "Zulfadhli Syarif — Fullstack Software Developer",
    description: "Desktop Apps · Web Based · Mobile Apps",
    images: [`${process.env.NEXT_PUBLIC_BASE_PATH ?? ""}/photo.jpg`],
  },
};

export const viewport: Viewport = { viewportFit: "cover", themeColor: "#141414" };

// Hides the page until the agent animation starts, unless the visitor prefers reduced motion.
const preBuild = `try{if(!matchMedia('(prefers-reduced-motion: reduce)').matches)document.documentElement.classList.add('js-build')}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className={`${poppins.variable} ${mono.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: preBuild }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
