import AgentBuilder from "@/components/AgentBuilder";
import CopyButton from "@/components/CopyButton";
import DotNav from "@/components/DotNav";
import { CapIcon, MailIcon, MedalIcon, PhoneIcon, SendIcon, UserIcon } from "@/components/Icons";
import { biodata, certificates, contact, education, experience, profile, projects, skills, stats } from "@/data/cv";

export default function Home() {
  return (
    <>
      <AgentBuilder />
      <DotNav />

      <main>
        {/* Hero */}
        <section className="hero" id="home">
          <div className="wrap hero-grid">
            <div className="photo">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={profile.photo} alt={`Foto ${profile.name}`} width={440} height={440} />
              <div className="status"><i />{profile.status}</div>
            </div>
            <div>
              <p className="hello">Halo, saya</p>
              <h1>{profile.name}</h1>
              <p className="role">{profile.role}</p>
              <p className="sub">{profile.sub}</p>
              <p className="about">{profile.about}</p>
              <div className="btns">
                <a className="btn btn-primary" href={contact.whatsapp} target="_blank" rel="noopener">Hubungi Saya (WhatsApp)</a>
                <a className="btn btn-ghost" href="#pengalaman">Lihat Pengalaman</a>
              </div>
              <div className="stats">
                {stats.map((s) => (
                  <div key={s.label}><b>{s.value}</b><span>{s.label}</span></div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Profil */}
        <section id="profil">
          <div className="wrap">
            <p className="eyebrow">Profil</p>
            <h2>Biodata &amp; Pendidikan</h2>
            <p className="lead">Lulusan Teknik Informatika dan Sistem Informasi, berdomisili di Medan, Sumatera Utara.</p>
            <div className="two">
              <div className="panel">
                <h3><UserIcon />Biodata</h3>
                <dl className="bio">
                  {biodata.map(([k, v]) => (
                    <div key={k} style={{ display: "contents" }}><dt>{k}</dt><dd>{v}</dd></div>
                  ))}
                </dl>
              </div>
              <div className="panel">
                <h3><CapIcon />Pendidikan</h3>
                <div className="edu">
                  {education.map((e) => (
                    <div className="edu-item" key={e.school}>
                      <b>{e.school}</b><span className="yr">{e.years}</span>
                      <span className="deg">{e.degree}</span>
                      <span className="ipk">{e.gpa}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Pengalaman */}
        <section id="pengalaman">
          <div className="wrap">
            <p className="eyebrow">Pengalaman Kerja</p>
            <h2>Perjalanan Karier</h2>
            <p className="lead">Dari backend API hingga sistem pemerintahan, membangun dan merawat aplikasi di berbagai skala.</p>
            <div className="timeline">
              {experience.map((j) => (
                <article className={j.current ? "job now" : "job"} key={j.company}>
                  <div className="card">
                    <div className="job-head">
                      <h3>{j.company}{j.current && <span className="pill">Saat ini</span>}</h3>
                      <span className="period">{j.period}</span>
                    </div>
                    <p className="pos">{j.position}</p>
                    <ul>{j.tasks.map((t) => <li key={t}>{t}</li>)}</ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Keahlian */}
        <section id="keahlian">
          <div className="wrap">
            <p className="eyebrow">Keahlian</p>
            <h2>Teknologi yang Saya Kuasai</h2>
            <p className="lead">Penilaian mandiri dalam skala 10.</p>
            <div className="skills">
              {skills.map(([n, v]) => (
                <div key={n}>
                  <div className="skill-top">{n}<span>{v}/10</span></div>
                  <div className="bar" role="img" aria-label={`${n} ${v} dari 10`}>
                    <i style={{ ["--w" as string]: `${v * 10}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Portofolio */}
        <section id="portofolio">
          <div className="wrap">
            <p className="eyebrow">Portofolio</p>
            <h2>Proyek Freelance</h2>
            <p className="lead">Aplikasi desktop, web, dan mobile untuk perusahaan, rumah sakit, dan instansi pemerintah sejak 2014.</p>
            <div className="projects">
              {projects.map((p) => (
                <article className="proj" key={p.title}>
                  {p.year && <span className="yr">{p.year}</span>}
                  <h3>{p.url ? <a href={p.url} target="_blank" rel="noopener">{p.title} ↗</a> : p.title}</h3>
                  {p.url && <span className="site">{p.url.replace("https://", "")}</span>}
                  <p>{p.desc}</p>
                  <div className="tags">{p.tags.map((t) => <span key={t}>{t}</span>)}</div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Sertifikat */}
        <section id="sertifikat">
          <div className="wrap">
            <p className="eyebrow">Sertifikat</p>
            <h2>Sertifikasi</h2>
            <p className="lead">Diterbitkan oleh StudySection E-Certification Center.</p>
            <div className="certs">
              {certificates.map((c) => (
                <div className="cert" key={c.title}>
                  <div className="ic"><MedalIcon /></div>
                  <div><b>{c.title}</b><span>{c.issuer}</span></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Kontak */}
        <section id="kontak">
          <div className="wrap">
            <p className="eyebrow">Kontak</p>
            <h2>Mari Bekerja Sama</h2>
            <p className="lead">Butuh aplikasi web, mobile, atau desktop untuk instansi maupun bisnis Anda? Klik tombol di bawah untuk terhubung langsung via WhatsApp.</p>
            <div className="contact-grid">
              <div className="ci">
                <div className="ic"><MailIcon /></div>
                <b>Email</b><span>{contact.email}</span>
                <CopyButton text={contact.email} label="Salin email" />
              </div>
              <div className="ci">
                <div className="ic"><PhoneIcon /></div>
                <b>Telepon / WA</b><span>{contact.phoneDisplay}</span>
                <CopyButton text={contact.phoneRaw} label="Salin nomor" />
              </div>
              <div className="ci">
                <div className="ic"><SendIcon /></div>
                <b>Telegram</b><span>{contact.telegram}</span>
              </div>
            </div>
            <div className="center">
              <a className="btn btn-primary cta" href={contact.whatsapp} target="_blank" rel="noopener">Hubungi Saya (WhatsApp)</a>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <div className="wrap">
          <span>© {new Date().getFullYear()} {profile.name}</span>
          <span>{profile.footerTagline}</span>
        </div>
      </footer>
    </>
  );
}
