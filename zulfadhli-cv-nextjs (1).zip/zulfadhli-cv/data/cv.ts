// Semua isi CV ada di file ini. Ubah di sini, halaman ikut berubah.

export const profile = {
  name: "Zulfadhli Syarif",
  role: "Fullstack Software Developer",
  sub: "Desktop Apps · Web Based · Mobile Apps",
  about:
    "Saya adalah seorang profesional muda yang berdedikasi dengan pengalaman lebih dari 10 tahun sebagai programmer Fullstack di berbagai perusahaan. Memiliki kemampuan komunikasi yang baik, dapat bekerja dengan cepat dan efisien, serta dapat bekerja di dalam tim.",
  status: "Bekerja di BPSDM Provsu",
  photo: `${process.env.NEXT_PUBLIC_BASE_PATH ?? ""}/photo.jpg`,
  footerTagline: "Fullstack Software Developer · Medan – Jakarta – Palembang – All Indonesia",
};

export const contact = {
  email: "zulfadlysyarief12@gmail.com",
  phoneDisplay: "0851-4793-2117",
  phoneRaw: "085147932117",
  whatsapp: "https://wa.me/6285147932117",
  telegram: "@zulfadli_sya1",
};

export const stats = [
  { value: "10+", label: "Tahun pengalaman" },
  { value: "5", label: "Tempat kerja" },
  { value: "12", label: "Proyek freelance" },
];

export const biodata: [string, string][] = [
  ["Tempat, Tgl Lahir", "Medan, 25 Maret 1995"],
  ["Kebangsaan", "Indonesia"],
  ["Tinggi / Berat", "170 cm / 82 kg"],
  ["Agama", "Islam"],
];

export const education = [
  { school: "Universitas Sriwijaya", degree: "S-1 Sistem Informasi", years: "2017 – 2022", gpa: "IPK 3,46" },
  { school: "Universitas Sumatera Utara", degree: "D-III Teknik Informatika", years: "2013 – 2016", gpa: "IPK 3,43" },
];

export type Job = { company: string; position: string; period: string; current?: boolean; tasks: string[] };

export const experience: Job[] = [
  {
    company: "PT Highland Urban Nusantara",
    position: "Founder & CEO",
    period: "2026 – Sekarang",
    current: true,
    tasks: [
      "Mendirikan dan memimpin perusahaan kopi arabika Gayo organik",
      "Membangun toko online hunorganiccoffe.com (Laravel)",
      "Mengelola kemitraan pengolahan kebun kopi bersama petani Gayo",
    ],
  },
  {
    company: "Badan Pengembangan Sumber Daya Manusia Provinsi Sumatera Utara",
    position: "Tenaga Ahli Utama – Programmer",
    period: "2022 – Sekarang",
    current: true,
    tasks: [
      "Maintenance dan perbaikan bug web",
      "Mengamankan data dan menjaga sistem keamanan",
      "Membangun web utama dan seluruh aplikasi di BPSDM (Laravel, Vue, Next.js, TypeScript)",
    ],
  },
  {
    company: "Universitas Tridinanti Palembang",
    position: "IT Programmer",
    period: "2020 – 2022",
    tasks: ["Fullstack: membangun aplikasi dan seluruh sistem", "Monitoring dan maintenance server", "Penetration testing"],
  },
  {
    company: "Bank Mandiri",
    position: "Mobile Programmer",
    period: "2018 – 2020",
    tasks: ["Membuat backend API Android", "Membuat dokumentasi API", "Maintenance dan perbaikan bug"],
  },
  {
    company: "PT Carilokak Indonesia",
    position: "Senior Backend Programmer",
    period: "2016 – 2018",
    tasks: ["Membuat backend API Android", "Membuat dokumentasi API", "Maintenance dan perbaikan bug backend aplikasi Android"],
  },
];

export const skills: [string, number][] = [
  ["Laravel", 10], ["NestJS", 10], ["Node.js, Next.js", 10], ["CodeIgniter, PHP Native", 10],
  ["Go, Gin", 10], ["Spring Boot", 9], ["Python", 9], ["TypeScript", 9],
  ["Flutter", 10], ["Kotlin (Native Android)", 9], ["React Native", 9], ["React.js", 9],
  ["VB.NET", 9], ["Bootstrap, Vue", 10], ["Tailwind", 10], ["Alpine.js", 9],
  ["SEO Optimization", 9], ["Rive", 8],
];

export type Project = { year?: number; title: string; desc: string; tags: string[]; url?: string };

export const projects: Project[] = [
  { year: 2026, title: "Station Rental", desc: "Marketplace tiket bus dan Hiace antarkota Aceh–Bali dengan akun mitra PO, rental mobil, dan paket wisata. Dua bahasa, pembayaran online DOKU.", tags: ["Laravel", "DOKU", "Multi-vendor"], url: "https://stationrental.com" },
  { year: 2026, title: "Medan88 Rent Car", desc: "Website rental mobil dengan pemesanan online, artikel SEO, dan notifikasi order ke admin.", tags: ["Laravel", "Tailwind", "Alpine.js"], url: "https://medan88rentcar.com" },
  { year: 2026, title: "Medan Rent Car", desc: "Website rental mobil dua bahasa (Inggris & Indonesia) untuk wisatawan lokal dan mancanegara, dengan pembayaran online DOKU.", tags: ["Laravel", "Tailwind", "Alpine.js"], url: "https://medanrentcar.com" },
  { title: "Aplikasi Rumah Sakit", desc: "Sistem informasi untuk mendukung layanan dan administrasi rumah sakit.", tags: ["Web App"] },
  { year: 2023, title: "Bakesbangpol Provsu", desc: "Aplikasi Android SIAP BERSINAR + backend web.", tags: ["Laravel", "Flutter", "Tailwind", "Rive", "Bootstrap"] },
  { year: 2022, title: "BPSDM Provsu", desc: "Aplikasi SIKEPAL berbasis web.", tags: ["Laravel", "Bootstrap"] },
  { year: 2022, title: "Dinas Kesehatan Provinsi Sumatera Utara", desc: "Aplikasi SISIMONEK berbasis web.", tags: ["Laravel", "Bootstrap"] },
  { year: 2020, title: "Web Token Crypto Chicibuyaken", desc: "Website crypto token.", tags: ["Laravel", "Bootstrap"] },
  { year: 2019, title: "Sumatera Express", desc: "Aplikasi Android + backend web.", tags: ["React", "Laravel", "Vue"] },
  { year: 2016, title: "VECTOR41 Based Project", desc: "Web utama dan sistem pengelolaan laporan proyek serta karyawan.", tags: ["PHP", "CSS", "JS", "HTML", "Bootstrap"] },
  { year: 2015, title: "PT Dewi Erge Nauli Moorlife (Medan – Pangkal Pinang)", desc: "Aplikasi POS berbasis desktop.", tags: ["VB.NET"] },
  { year: 2014, title: "PLN UPB Sumbagut", desc: "Aplikasi manajemen folder laporan listrik pada komputer server SCADA berbasis desktop.", tags: ["VB.NET"] },
];

export const certificates = [
  { title: "Laravel Fullstack Developer Advanced", issuer: "StudySection" },
  { title: "Laravel 5.x Advanced", issuer: "StudySection" },
];

export const sections = [
  { id: "home", label: "Home" },
  { id: "profil", label: "Profil" },
  { id: "pengalaman", label: "Pengalaman" },
  { id: "keahlian", label: "Keahlian" },
  { id: "portofolio", label: "Portofolio" },
  { id: "sertifikat", label: "Sertifikat" },
  { id: "kontak", label: "Kontak" },
];
