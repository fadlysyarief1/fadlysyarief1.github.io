/** @type {import('next').NextConfig} */
// NEXT_PUBLIC_BASE_PATH diisi otomatis oleh GitHub Actions (mis. "/zulfadhli-cv").
// Kosong saat npm run dev, atau saat repo bernama <username>.github.io / pakai domain sendiri.
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";

const nextConfig = {
  output: "export", // hasil build statis di folder out/ (GitHub Pages, cPanel, Vercel)
  basePath,
  images: { unoptimized: true },
  trailingSlash: true,
};
export default nextConfig;
