const base = { fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };

export const UserIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...base}><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-6 8-6s8 2 8 6" /></svg>
);
export const CapIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...base}><path d="M22 10 12 5 2 10l10 5 10-5z" /><path d="M6 12v5c3 2 9 2 12 0v-5" /></svg>
);
export const MedalIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" {...base}><circle cx="12" cy="9" r="6" /><path d="m8.5 14-1.5 8 5-3 5 3-1.5-8" /></svg>
);
export const MailIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" {...base}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></svg>
);
export const PhoneIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" {...base}><rect x="6" y="2" width="12" height="20" rx="2.5" /><path d="M11 18h2" /></svg>
);
export const SendIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" {...base}><path d="M22 2 11 13" /><path d="M22 2 15 22l-4-9-9-4 20-7z" /></svg>
);
