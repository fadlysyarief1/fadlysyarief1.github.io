"use client";

/*
 * 14 "AI agents" (coloured cursors) build the page layer by layer:
 * each one flies to an element, draws a blue selection box with its size,
 * and the element fades in. The page scrolls along with the build.
 */

import { useEffect, useRef, useState } from "react";

const SEL =
  ".dots,.photo,.photo img,.status,.hello,.hero h1,.role,.sub,.about,.btn,.stats>div,.eyebrow,h2,.lead,.panel,.panel h3,dl.bio dt,dl.bio dd,.edu-item,.job,.job-head,.pos,.job li,.skills>div,.proj,.proj h3,.proj p,.cert,.ci,footer .wrap>span";

const COLORS = ["#f5c518", "#4fd1c5", "#7c83ff", "#ff7a59", "#7ee081", "#ff6fb5", "#5ab0ff", "#c084fc", "#fb923c", "#34d399", "#f87171", "#a3e635", "#38bdf8", "#e879f9"];

const BASE_SPEED = 0.5; // 1 = original pace; lower is slower
const SPEEDS = [1, 2, 4];

type Rect = { x: number; y: number; w: number; h: number };
type Layer = { el: HTMLElement; parent: Layer | null; state: 0 | 1 | 2; rect: Rect | null };
type Agent = {
  a: HTMLDivElement; b: HTMLDivElement;
  x: number; y: number; fx: number; fy: number; tx: number; ty: number;
  t: number; dur: number; phase: "idle" | "move" | "wander" | "select"; wait: number; l: Layer | null; shown: boolean;
};

export default function AgentBuilder() {
  const stageRef = useRef<HTMLDivElement>(null);
  const doneRef = useRef<HTMLSpanElement>(null);
  const totalRef = useRef<HTMLSpanElement>(null);
  const fillRef = useRef<HTMLElement>(null);
  const api = useRef<{ start: () => void; close: () => void; setSpeed: (s: number) => void } | null>(null);
  const [speedIdx, setSpeedIdx] = useState(0);
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    const html = document.documentElement;
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const stage = stageRef.current!;
    const els = Array.from(document.querySelectorAll<HTMLElement>(SEL));
    const set = new Set<Element>(els);
    const L: Layer[] = els.map((el) => ({ el, parent: null, state: 0, rect: null }));
    const byEl = new Map(L.map((l) => [l.el as Element, l]));
    L.forEach((l) => {
      let p = l.el.parentElement;
      while (p && !set.has(p)) p = p.parentElement;
      l.parent = p ? byEl.get(p) ?? null : null;
    });
    totalRef.current!.textContent = String(L.length);

    let speed = 1, done = 0, building = false, follow = true, running = !reduce, last = 0, raf = 0;
    const rnd = (a: number, b: number) => a + Math.random() * (b - a);
    const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
    const docRect = (el: Element): Rect => {
      const r = el.getBoundingClientRect();
      return { x: r.left + scrollX, y: r.top + scrollY, w: r.width, h: r.height };
    };

    const agents: Agent[] = COLORS.map(() => {
      const a = document.createElement("div");
      a.className = "agent";
      const b = document.createElement("div");
      b.className = "selbox";
      b.innerHTML = "<i></i><i></i><i></i><i></i><b></b>";
      stage.append(b, a);
      return { a, b, x: rnd(0, innerWidth), y: rnd(0, innerHeight * 0.8), fx: 0, fy: 0, tx: 0, ty: 0, t: 0, dur: 1, phase: "idle", wait: rnd(0, 500), l: null, shown: false };
    });
    agents.forEach((ag, i) => {
      ag.a.innerHTML = `<svg width="20" height="25" viewBox="0 0 20 25"><path d="M2 2 L2 20 L7 15.6 L10.4 23 L13.4 21.6 L10 14.4 L16.4 14.4 Z" fill="${COLORS[i]}" stroke="rgba(0,0,0,.6)" stroke-width="1.3" stroke-linejoin="round"/></svg>`;
    });
    const place = (ag: Agent) => (ag.a.style.transform = `translate(${ag.x - 2}px,${ag.y - 2}px)`);
    agents.forEach(place);

    const setCount = () => {
      doneRef.current!.textContent = String(done);
      fillRef.current!.style.width = (done / L.length) * 100 + "%";
    };
    const complete = () => {
      building = false;
      setTimeout(() => { if (!building) L.forEach((l) => l.el.classList.remove("ly", "on")); }, 600);
    };
    const finishLayer = (l: Layer) => {
      if (l.state === 2) return;
      l.state = 2;
      l.el.classList.add("on");
      done++;
      setCount();
      if (done === L.length) complete();
    };
    const pick = (): Layer | null => {
      for (const l of L) {
        if (l.state !== 0) continue;
        if (l.parent && l.parent.state !== 2) continue;
        const r = docRect(l.el);
        if (r.w * r.h < 1) { finishLayer(l); continue; }
        l.state = 1; l.rect = r; return l;
      }
      return null;
    };
    const moveTo = (ag: Agent, x: number, y: number, minD: number, maxD: number) => {
      ag.fx = ag.x; ag.fy = ag.y; ag.tx = x; ag.ty = y; ag.t = 0;
      ag.dur = Math.min(maxD, Math.max(minD, Math.hypot(x - ag.x, y - ag.y) / 1.5));
    };
    const showBox = (ag: Agent, r: Rect) => {
      const b = ag.b;
      b.style.transform = `translate(${r.x - 3}px,${r.y - 3}px)`;
      b.style.width = r.w + 6 + "px";
      b.style.height = r.h + 6 + "px";
      (b.lastChild as HTMLElement).textContent = `${Math.round(r.w)} × ${Math.round(r.h)}`;
      b.classList.add("show");
    };

    const step = (ag: Agent, dt: number) => {
      if (ag.wait > 0) { ag.wait -= dt; return; }
      if (ag.phase === "idle") {
        const l = building ? pick() : null;
        if (l && l.rect) {
          ag.l = l;
          const r = l.rect;
          moveTo(ag, r.x + Math.min(r.w * 0.35, 48) + rnd(-6, 6), r.y + Math.min(r.h * 0.5, 22) + rnd(-4, 4), 260, 900);
          ag.phase = "move";
        } else {
          moveTo(ag, rnd(30, innerWidth - 40) + scrollX, scrollY + rnd(60, innerHeight - 90), 900, 2600);
          ag.phase = "wander";
        }
      } else if (ag.phase === "move" || ag.phase === "wander") {
        ag.t += dt;
        const p = ease(Math.min(1, ag.t / ag.dur));
        ag.x = ag.fx + (ag.tx - ag.fx) * p;
        ag.y = ag.fy + (ag.ty - ag.fy) * p;
        if (ag.t >= ag.dur) {
          if (ag.phase === "move" && ag.l?.rect) { ag.phase = "select"; ag.t = 0; ag.shown = false; showBox(ag, ag.l.rect); }
          else { ag.phase = "idle"; ag.wait = building ? 0 : rnd(300, 1600); }
        }
      } else if (ag.phase === "select" && ag.l) {
        ag.t += dt;
        if (!ag.shown && ag.t > 180) { ag.shown = true; ag.l.el.classList.add("on"); }
        if (ag.t > 480) { ag.b.classList.remove("show"); finishLayer(ag.l); ag.l = null; ag.phase = "idle"; ag.wait = rnd(0, 140); }
      }
    };

    const autoScroll = (dt: number) => {
      if (!follow || !building) return;
      let front = Infinity;
      for (const l of L) if (l.state === 1 && l.rect && l.rect.y < front) front = l.rect.y;
      if (front === Infinity) return;
      const target = Math.min(front - innerHeight * 0.32, document.documentElement.scrollHeight - innerHeight);
      if (target > scrollY + 1) window.scrollTo({ top: scrollY + (target - scrollY) * Math.min(1, dt * 0.0035 * speed), behavior: "instant" as ScrollBehavior });
    };

    const loop = (ts: number) => {
      if (!running) return;
      const dt = Math.min(50, last ? ts - last : 16) * speed * BASE_SPEED;
      last = ts;
      agents.forEach((ag) => { step(ag, dt); place(ag); });
      autoScroll(dt / speed);
      raf = requestAnimationFrame(loop);
    };

    const start = () => {
      L.forEach((l) => { l.state = 0; l.rect = null; l.el.classList.remove("on"); l.el.classList.add("ly"); });
      agents.forEach((ag) => { ag.phase = "idle"; ag.l = null; ag.b.classList.remove("show"); ag.wait = rnd(0, 400); });
      done = 0; setCount(); follow = true; building = true;
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
      stage.hidden = false;
      if (!running) { running = true; last = 0; raf = requestAnimationFrame(loop); }
    };
    const close = () => {
      L.forEach((l) => { if (l.state !== 2) { l.state = 2; done++; } });
      setCount();
      building = false;
      L.forEach((l) => l.el.classList.remove("ly", "on"));
      running = false;
      cancelAnimationFrame(raf);
      stage.hidden = true;
    };
    api.current = { start, close, setSpeed: (s) => (speed = s) };

    const stopFollow = () => (follow = false);
    const onKey = (e: KeyboardEvent) => {
      if (["ArrowDown", "ArrowUp", "PageDown", "PageUp", "Space", "Home", "End"].includes(e.code)) stopFollow();
    };
    const anchors = Array.from(document.querySelectorAll('a[href^="#"]'));
    addEventListener("wheel", stopFollow, { passive: true });
    addEventListener("touchmove", stopFollow, { passive: true });
    addEventListener("keydown", onKey);
    anchors.forEach((a) => a.addEventListener("click", stopFollow));

    let timer: ReturnType<typeof setTimeout> | undefined;
    if (reduce) {
      done = L.length; setCount(); stage.hidden = true;
    } else {
      L.forEach((l) => l.el.classList.add("ly"));
      html.classList.remove("js-build");
      building = true; setCount();
      const go = () => { timer = setTimeout(() => (raf = requestAnimationFrame(loop)), 350); };
      document.fonts?.ready ? document.fonts.ready.then(go) : go();
    }

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      if (timer) clearTimeout(timer);
      removeEventListener("wheel", stopFollow);
      removeEventListener("touchmove", stopFollow);
      removeEventListener("keydown", onKey);
      anchors.forEach((a) => a.removeEventListener("click", stopFollow));
      L.forEach((l) => l.el.classList.remove("ly", "on"));
      stage.innerHTML = "";
      html.classList.remove("js-build");
    };
  }, []);

  return (
    <>
      <div id="stage" ref={stageRef} aria-hidden="true" />
      <div id="dock" role="status" aria-live="off" hidden={closed}>
        <span className="avs">
          {COLORS.slice(0, 5).map((c) => <span key={c} style={{ background: c }} />)}
        </span>
        <b>14 agents</b>
        <span className="muted"><span ref={doneRef}>0</span> / <span ref={totalRef}>0</span> layers</span>
        <span className="prog"><i ref={fillRef} /></span>
        <button type="button" onClick={() => api.current?.start()}>Tour</button>
        <button
          type="button"
          aria-label="Kecepatan"
          onClick={() => {
            const next = (speedIdx + 1) % SPEEDS.length;
            setSpeedIdx(next);
            api.current?.setSpeed(SPEEDS[next]);
          }}
        >
          {SPEEDS[speedIdx]}x
        </button>
        <button type="button" aria-label="Tutup animasi" onClick={() => { api.current?.close(); setClosed(true); }}>×</button>
      </div>
    </>
  );
}
