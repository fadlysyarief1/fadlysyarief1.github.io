"use client";

import { useEffect, useState } from "react";
import { sections } from "@/data/cv";

export default function DotNav() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const els = sections.map((s) => document.getElementById(s.id));
    const mark = () => {
      let i = 0;
      els.forEach((el, k) => {
        if (el && el.getBoundingClientRect().top <= innerHeight * 0.4) i = k;
      });
      if (innerHeight + scrollY >= document.documentElement.scrollHeight - 4) i = els.length - 1;
      setActive(i);
    };
    mark();
    addEventListener("scroll", mark, { passive: true });
    addEventListener("resize", mark);
    return () => {
      removeEventListener("scroll", mark);
      removeEventListener("resize", mark);
    };
  }, []);

  return (
    <nav className="dots" aria-label="Navigasi bagian">
      {sections.map((s, k) => (
        <a key={s.id} href={`#${s.id}`} className={k === active ? "active" : undefined} aria-current={k === active ? "true" : undefined}>
          <span>{s.label}</span>
        </a>
      ))}
    </nav>
  );
}
