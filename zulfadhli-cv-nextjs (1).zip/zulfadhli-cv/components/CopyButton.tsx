"use client";

import { useState } from "react";

export default function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);

  const onClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const target = e.currentTarget.previousElementSibling;
    const select = () => {
      if (!target) return;
      const r = document.createRange();
      r.selectNodeContents(target);
      const s = getSelection();
      s?.removeAllRanges();
      s?.addRange(r);
    };
    try {
      navigator.clipboard.writeText(text).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      }, select);
    } catch {
      select();
    }
  };

  return (
    <button type="button" className="copy" onClick={onClick}>
      {copied ? "Tersalin" : label}
    </button>
  );
}
